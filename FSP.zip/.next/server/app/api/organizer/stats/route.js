(()=>{var t={};t.id=4453,t.ids=[4453],t.modules={3295:t=>{"use strict";t.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},7462:(t,e,r)=>{"use strict";r.d(e,{A:()=>i});let i=(0,r(88909).lw)("postgresql://neondb_owner:npg_pLImMPQx90kw@ep-shy-snow-a2vkpjfh-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require")},10846:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},83794:(t,e,r)=>{"use strict";r.r(e),r.d(e,{patchFetch:()=>l,routeModule:()=>c,serverHooks:()=>g,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>m});var i={};r.r(i),r.d(i,{GET:()=>u});var a=r(96559),s=r(48088),n=r(37719),o=r(32190),p=r(7462);async function u(t){try{let{searchParams:e}=new URL(t.url),r=e.get("organizerId");if(!r)return o.NextResponse.json({error:"Organizer ID is required"},{status:400});let i=`
      SELECT COUNT(*) as total_competitions
      FROM "Competition"
      WHERE "organizerId" = $1
    `,a=await (0,p.A)(i,[r]),s=Number.parseInt(a[0].total_competitions)||0,n=`
      SELECT COUNT(*) as active_competitions
      FROM "Competition"
      WHERE "organizerId" = $1 AND status IN ('REGISTRATION_OPEN', 'IN_PROGRESS')
    `,u=await (0,p.A)(n,[r]),c=Number.parseInt(u[0].active_competitions)||0,d=`
      SELECT COUNT(*) as total_registrations
      FROM "Registration" r
      JOIN "Competition" c ON r."competitionId" = c.id
      WHERE c."organizerId" = $1
    `,m=await (0,p.A)(d,[r]),g=Number.parseInt(m[0].total_registrations)||0,l=`
      SELECT COUNT(*) as pending_registrations
      FROM "Registration" r
      JOIN "Competition" c ON r."competitionId" = c.id
      WHERE c."organizerId" = $1 AND r.status = 'PENDING'
    `,E=await (0,p.A)(l,[r]),R=Number.parseInt(E[0].pending_registrations)||0,I=`
      SELECT r.id, r.status, r."createdAt", c.title as competition_title, u.name as user_name
      FROM "Registration" r
      JOIN "Competition" c ON r."competitionId" = c.id
      JOIN "User" u ON r."userId" = u.id
      WHERE c."organizerId" = $1
      ORDER BY r."createdAt" DESC
      LIMIT 5
    `,N=(await (0,p.A)(I,[r])).map(t=>({id:t.id,status:t.status,createdAt:t.createdAt,competitionTitle:t.competition_title,userName:t.user_name})),O=`
      SELECT id, title, "eventStart", "currentParticipants", "maxParticipants"
      FROM "Competition"
      WHERE "organizerId" = $1 AND "eventStart" > NOW()
      ORDER BY "eventStart" ASC
      LIMIT 3
    `,x=(await (0,p.A)(O,[r])).map(t=>({id:t.id,title:t.title,eventStart:t.eventStart,currentParticipants:t.currentParticipants||0,maxParticipants:t.maxParticipants}));return o.NextResponse.json({totalCompetitions:s,activeCompetitions:c,totalRegistrations:g,pendingRegistrations:R,recentRegistrations:N,upcomingCompetitions:x})}catch(t){return console.error("Error fetching organizer stats:",t),o.NextResponse.json({error:"Failed to fetch organizer stats"},{status:500})}}let c=new a.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/organizer/stats/route",pathname:"/api/organizer/stats",filename:"route",bundlePath:"app/api/organizer/stats/route"},resolvedPagePath:"C:\\Users\\user\\Desktop\\HACATOn-ract\\app\\api\\organizer\\stats\\route.ts",nextConfigOutput:"",userland:i}),{workAsyncStorage:d,workUnitAsyncStorage:m,serverHooks:g}=c;function l(){return(0,n.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:m})}},96487:()=>{}};var e=require("../../../../webpack-runtime.js");e.C(t);var r=t=>e(e.s=t),i=e.X(0,[4243,8909,580],()=>r(83794));module.exports=i})();