(()=>{var e={};e.id=2052,e.ids=[2052],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},7462:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let a=(0,r(88909).lw)("postgresql://neondb_owner:npg_pLImMPQx90kw@ep-shy-snow-a2vkpjfh-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},89156:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>I,routeModule:()=>c,serverHooks:()=>E,workAsyncStorage:()=>m,workUnitAsyncStorage:()=>l});var a={};r.r(a),r.d(a,{GET:()=>d,POST:()=>u});var s=r(96559),n=r(48088),o=r(37719),i=r(32190),p=r(7462);async function d(e){try{let{searchParams:t}=new URL(e.url),r=t.get("userId"),a=t.get("competitionId"),s=(0,p.A)`
      SELECT t.*, c.title as competition_title, u.name as captain_name,
      (SELECT COUNT(*) FROM "TeamMember" tm WHERE tm."teamId" = t.id) as member_count
      FROM "Team" t
      LEFT JOIN "Competition" c ON t."competitionId" = c.id
      LEFT JOIN "User" u ON t."captainId" = u.id
      WHERE 1=1
    `;r&&(s=(0,p.A)`
        ${s} AND t.id IN (SELECT "teamId" FROM "TeamMember" WHERE "userId" = ${r})
      `),a&&(s=(0,p.A)`
        ${s} AND t."competitionId" = ${a}
      `),s=(0,p.A)`
      ${s} ORDER BY t."createdAt" DESC
    `;let n=(await s).map(e=>({id:e.id,name:e.name,competitionId:e.competitionId,competitionTitle:e.competition_title,captainId:e.captainId,captainName:e.captain_name,status:e.status,memberCount:Number.parseInt(e.member_count)||0,createdAt:e.createdAt,updatedAt:e.updatedAt}));return i.NextResponse.json(n)}catch(e){return console.error("Error fetching teams:",e),i.NextResponse.json({error:"Failed to fetch teams"},{status:500})}}async function u(e){try{let t=await e.json(),{name:r,competitionId:a,captainId:s}=t,n=`team_${Date.now()}`,o=new Date,d=await (0,p.A)`
      INSERT INTO "Team" (
        id, name, "competitionId", "captainId", status, "createdAt", "updatedAt"
      )
      VALUES (
        ${n}, ${r}, ${a}, ${s}, ${t.status||"NEEDS_MEMBERS"}, ${o}, ${o}
      )
      RETURNING *
    `;return await (0,p.A)`
      INSERT INTO "TeamMember" (
        id, "teamId", "userId", "isCaptain", "joinedAt"
      )
      VALUES (
        ${"tm_"+Date.now()}, ${n}, ${s}, ${!0}, ${o}
      )
    `,i.NextResponse.json(d[0],{status:201})}catch(e){return console.error("Error creating team:",e),i.NextResponse.json({error:"Failed to create team"},{status:500})}}let c=new s.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/teams/route",pathname:"/api/teams",filename:"route",bundlePath:"app/api/teams/route"},resolvedPagePath:"C:\\Users\\user\\Desktop\\HACATOn-ract\\app\\api\\teams\\route.ts",nextConfigOutput:"",userland:a}),{workAsyncStorage:m,workUnitAsyncStorage:l,serverHooks:E}=c;function I(){return(0,o.patchFetch)({workAsyncStorage:m,workUnitAsyncStorage:l})}},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[4243,8909,580],()=>r(89156));module.exports=a})();