(()=>{var e={};e.id=8840,e.ids=[8840],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},7462:(e,t,r)=>{"use strict";r.d(t,{A:()=>n});let n=(0,r(88909).lw)("postgresql://neondb_owner:npg_pLImMPQx90kw@ep-shy-snow-a2vkpjfh-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},37674:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>x,routeModule:()=>l,serverHooks:()=>g,workAsyncStorage:()=>m,workUnitAsyncStorage:()=>E});var n={};r.r(n),r.d(n,{DELETE:()=>c,GET:()=>d,PUT:()=>u});var i=r(96559),s=r(48088),a=r(37719),o=r(32190),p=r(7462);async function d(e,{params:t}){try{let e=t.id,r=`
      SELECT c.*, u.name as organizer_name, u.email as organizer_email
      FROM "Competition" c
      LEFT JOIN "User" u ON c."organizerId" = u.id
      WHERE c.id = $1
    `,n=await (0,p.A)(r,[e]);if(0===n.length)return o.NextResponse.json({error:"Competition not found"},{status:404});let i=n[0],s=`
      SELECT t.*, u.name as captain_name
      FROM "Team" t
      LEFT JOIN "User" u ON t."captainId" = u.id
      WHERE t."competitionId" = $1
    `,a=await (0,p.A)(s,[e]),d={id:i.id,title:i.title,type:i.type,discipline:i.discipline,description:i.description,rules:i.rules,prizes:i.prizes,region:i.region,registrationStart:i.registrationStart,registrationEnd:i.registrationEnd,eventStart:i.eventStart,eventEnd:i.eventEnd,maxParticipants:i.maxParticipants,currentParticipants:i.currentParticipants||0,status:i.status,createdAt:i.createdAt,updatedAt:i.updatedAt,organizer:{id:i.organizerId,name:i.organizer_name,email:i.organizer_email},teams:a.map(e=>({id:e.id,name:e.name,status:e.status,captain:{id:e.captainId,name:e.captain_name}}))};return o.NextResponse.json(d)}catch(e){return console.error("Error fetching competition:",e),o.NextResponse.json({error:"Failed to fetch competition"},{status:500})}}async function u(e,{params:t}){try{let r=t.id,n=await e.json(),i=`
      UPDATE "Competition"
      SET 
        title = $1,
        type = $2,
        discipline = $3,
        description = $4,
        rules = $5,
        prizes = $6,
        region = $7,
        "registrationStart" = $8,
        "registrationEnd" = $9,
        "eventStart" = $10,
        "eventEnd" = $11,
        "maxParticipants" = $12,
        status = $13,
        "updatedAt" = $14
      WHERE id = $15
      RETURNING *
    `,s=await (0,p.A)(i,[n.title,n.type,n.discipline,n.description,n.rules,n.prizes,n.region,new Date(n.registrationStart),new Date(n.registrationEnd),new Date(n.eventStart),new Date(n.eventEnd),n.maxParticipants,n.status,new Date,r]);if(0===s.length)return o.NextResponse.json({error:"Competition not found"},{status:404});return o.NextResponse.json(s[0])}catch(e){return console.error("Error updating competition:",e),o.NextResponse.json({error:"Failed to update competition"},{status:500})}}async function c(e,{params:t}){try{let e=t.id,r=`
      DELETE FROM "Competition"
      WHERE id = $1
      RETURNING *
    `,n=await (0,p.A)(r,[e]);if(0===n.length)return o.NextResponse.json({error:"Competition not found"},{status:404});return o.NextResponse.json({success:!0})}catch(e){return console.error("Error deleting competition:",e),o.NextResponse.json({error:"Failed to delete competition"},{status:500})}}let l=new i.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/competitions/[id]/route",pathname:"/api/competitions/[id]",filename:"route",bundlePath:"app/api/competitions/[id]/route"},resolvedPagePath:"C:\\Users\\user\\Desktop\\HACATOn-ract\\app\\api\\competitions\\[id]\\route.ts",nextConfigOutput:"",userland:n}),{workAsyncStorage:m,workUnitAsyncStorage:E,serverHooks:g}=l;function x(){return(0,a.patchFetch)({workAsyncStorage:m,workUnitAsyncStorage:E})}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[4243,8909,580],()=>r(37674));module.exports=n})();