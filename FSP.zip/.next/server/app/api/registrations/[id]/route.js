(()=>{var e={};e.id=8622,e.ids=[8622],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},7462:(e,t,r)=>{"use strict";r.d(t,{A:()=>s});let s=(0,r(88909).lw)("postgresql://neondb_owner:npg_pLImMPQx90kw@ep-shy-snow-a2vkpjfh-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},50053:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>R,routeModule:()=>l,serverHooks:()=>m,workAsyncStorage:()=>E,workUnitAsyncStorage:()=>g});var s={};r.r(s),r.d(s,{DELETE:()=>c,GET:()=>p,PUT:()=>d});var i=r(96559),n=r(48088),o=r(37719),a=r(32190),u=r(7462);async function p(e,{params:t}){try{let e=t.id,r=`
      SELECT r.*, c.title as competition_title, u.name as user_name, u.email as user_email
      FROM "Registration" r
      LEFT JOIN "Competition" c ON r."competitionId" = c.id
      LEFT JOIN "User" u ON r."userId" = u.id
      WHERE r.id = $1
    `,s=await (0,u.A)(r,[e]);if(0===s.length)return a.NextResponse.json({error:"Registration not found"},{status:404});let i=s[0],n={id:i.id,competitionId:i.competitionId,competitionTitle:i.competition_title,userId:i.userId,userName:i.user_name,userEmail:i.user_email,status:i.status,paymentStatus:i.paymentStatus,createdAt:i.createdAt,updatedAt:i.updatedAt};return a.NextResponse.json(n)}catch(e){return console.error("Error fetching registration:",e),a.NextResponse.json({error:"Failed to fetch registration"},{status:500})}}async function d(e,{params:t}){try{let r=t.id,s=await e.json(),i=`
      UPDATE "Registration"
      SET 
        status = $1,
        "paymentStatus" = $2,
        "updatedAt" = $3
      WHERE id = $4
      RETURNING *
    `,n=await (0,u.A)(i,[s.status,s.paymentStatus,new Date,r]);if(0===n.length)return a.NextResponse.json({error:"Registration not found"},{status:404});return a.NextResponse.json(n[0])}catch(e){return console.error("Error updating registration:",e),a.NextResponse.json({error:"Failed to update registration"},{status:500})}}async function c(e,{params:t}){try{let e=t.id,r=`
      SELECT "competitionId" FROM "Registration"
      WHERE id = $1
    `,s=await (0,u.A)(r,[e]);if(0===s.length)return a.NextResponse.json({error:"Registration not found"},{status:404});let i=s[0].competitionId,n=`
      DELETE FROM "Registration"
      WHERE id = $1
      RETURNING *
    `;return await (0,u.A)(n,[e]),await (0,u.A)(`
      UPDATE "Competition"
      SET "currentParticipants" = GREATEST("currentParticipants" - 1, 0)
      WHERE id = $1
    `,[i]),a.NextResponse.json({success:!0})}catch(e){return console.error("Error deleting registration:",e),a.NextResponse.json({error:"Failed to delete registration"},{status:500})}}let l=new i.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/registrations/[id]/route",pathname:"/api/registrations/[id]",filename:"route",bundlePath:"app/api/registrations/[id]/route"},resolvedPagePath:"C:\\Users\\user\\Desktop\\HACATOn-ract\\app\\api\\registrations\\[id]\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:E,workUnitAsyncStorage:g,serverHooks:m}=l;function R(){return(0,o.patchFetch)({workAsyncStorage:E,workUnitAsyncStorage:g})}},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4243,8909,580],()=>r(50053));module.exports=s})();