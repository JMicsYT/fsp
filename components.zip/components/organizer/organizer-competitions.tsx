// components/organizer/organizer-competitions.tsx
"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Calendar, MapPin, Users, Edit, Trash2, Eye } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface Competition {
  id: string
  title: string
  type: "OPEN" | "REGIONAL" | "FEDERAL"
  discipline: string
  region: string
  eventStart: string
  eventEnd: string
  status: string
  currentParticipants: number
  maxParticipants: number | null
  registrationCount: number
}

export function OrganizerCompetitions({ userId }: { userId: string }) {
  const [competitions, setCompetitions] = useState<Competition[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchCompetitions = async () => {
      try {
        setIsLoading(true)
        // Обратите внимание: параметр — organizerId, а не userId
        const response = await fetch(
          `/api/organizer/competitions?organizerId=${encodeURIComponent(
            userId
          )}`,
          { cache: "no-store" }
        )
        if (!response.ok) {
          throw new Error(`Status ${response.status}`)
        }
        // Обязательно вызвать .json()
        const data: Competition[] = await response.json()
        setCompetitions(data)
      } catch (error) {
        console.error("Error fetching competitions:", error)
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить ваши соревнования",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchCompetitions()
  }, [userId, toast])

  if (isLoading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-12 w-full" />
        ))}
      </div>
    )
  }

  if (competitions.length === 0) {
    return (
      <div className="text-center text-muted-foreground">
        У вас пока нет соревнований
        <div className="mt-4">
          <Link href="/competitions/create">
            <Button>Создать соревнование</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Название</TableHead>
          <TableHead>Тип</TableHead>
          <TableHead>Дисциплина</TableHead>
          <TableHead>Дата</TableHead>
          <TableHead>Регистрация</TableHead>
          <TableHead className="text-right">Действия</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {competitions.map((c) => (
          <TableRow key={c.id}>
            <TableCell>{c.title}</TableCell>
            <TableCell>{c.type}</TableCell>
            <TableCell>{c.discipline}</TableCell>
            <TableCell>
              <Calendar className="inline-block mr-1 h-4 w-4 text-muted-foreground" />
              {new Date(c.eventStart).toLocaleDateString()}–
              {new Date(c.eventEnd).toLocaleDateString()}
            </TableCell>
            <TableCell>
              <Users className="inline-block mr-1 h-4 w-4 text-muted-foreground" />
              {c.registrationCount}
            </TableCell>
            <TableCell className="text-right space-x-2">
              <Link href={`/competitions/${c.id}`}>
                <Button size="icon" variant="ghost" title="Просмотр">
                  <Eye size={16} />
                </Button>
              </Link>
              <Link href={`/competitions/${c.id}/edit`}>
                <Button size="icon" variant="ghost" title="Редактировать">
                  <Edit size={16} />
                </Button>
              </Link>
              <AlertDialog>
                <AlertDialogHeader>
                  <AlertDialogTitle>Удалить соревнование?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Это действие нельзя отменить. Все данные будут безвозвратно удалены.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Отмена</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => {
                      /* ваш handleDelete(c.id) */
                    }}
                    className="bg-destructive text-destructive-foreground"
                  >
                    Удалить
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialog>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
