"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, MapPin, Users } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/hooks/use-toast"

interface Competition {
  id: string
  title: string
  type: string
  discipline: string
  registrationStart: string
  registrationEnd: string
  eventStart: string
  eventEnd: string
  region: string
  maxParticipants: number | null
  currentParticipants: number
  status: string
}

export function CompetitionsList() {
  const [competitions, setCompetitions] = useState<Competition[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()
  const searchParams = useSearchParams()

  useEffect(() => {
    const fetchCompetitions = async () => {
      try {
        setIsLoading(true)

        // Собираем фильтры в строку запроса (оставляем только search-параметры)
        const params = new URLSearchParams()
        const search = searchParams?.get("search")
        if (search) params.append("search", search)
        const types = searchParams?.getAll("type") || []
        types.forEach((t) => params.append("type", t))
        const discipline = searchParams?.get("discipline")
        if (discipline && discipline !== "all") params.append("discipline", discipline)
        const region = searchParams?.get("region")
        if (region && region !== "all") params.append("region", region)
        const statuses = searchParams?.getAll("status") || []
        statuses.forEach((s) => params.append("status", s))
        const fromDate = searchParams?.get("fromDate")
        if (fromDate) params.append("fromDate", fromDate)
        const toDate = searchParams?.get("toDate")
        if (toDate) params.append("toDate", toDate)

        const query = params.toString()
        const url = `/api/competitions${query ? `?${query}` : ""}`

        console.log("🛰️ Fetching competitions from:", url)
        const res = await fetch(url, { cache: "no-store" })
        if (!res.ok) throw new Error("Failed to fetch competitions")

        const data: Competition[] = await res.json()
        console.log("🛰️ competitions data:", data)

        setCompetitions(data)
      } catch (error) {
        console.error("Error fetching competitions:", error)
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить соревнования",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchCompetitions()
  }, [searchParams, toast])

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-[200px] w-full" />
        <Skeleton className="h-[200px] w-full" />
        <Skeleton className="h-[200px] w-full" />
      </div>
    )
  }

  if (competitions.length === 0) {
    return (
      <div className="text-center text-muted-foreground">
        Ничего не найдено
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {competitions.map((c) => (
        <Card key={c.id} className="flex flex-col">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>{c.title}</CardTitle>
              <Badge>{c.type}</Badge>
            </div>
          </CardHeader>
          <CardContent className="flex-1 space-y-2">
            <div className="flex items-center">
              <Users className="mr-2 h-4 w-4" />
              <span>{c.currentParticipants} участников</span>
            </div>
            <div className="flex items-center">
              <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
              <span>
                {new Date(c.eventStart).toLocaleDateString()} —{" "}
                {new Date(c.eventEnd).toLocaleDateString()}
              </span>
            </div>
            <div className="flex items-center">
              <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
              <span>{c.region}</span>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Link href={`/competitions/${c.id}`}>
              <Button size="sm">Подробнее</Button>
            </Link>
            {c.status === "REGISTRATION_OPEN" && (
              <Link href={`/competitions/register/${c.id}`}>
                <Button size="sm" variant="outline">
                  Зарегистрироваться
                </Button>
              </Link>
            )}
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
