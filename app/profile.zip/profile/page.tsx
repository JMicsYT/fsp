// app/profile/page.tsx
import { getServerSession } from "next-auth/next"
import { redirect } from "next/navigation"
import sql from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, User, Mail, Phone } from "lucide-react"
import { ProfileCompetitions } from "@/components/profile/profile-competitions"
import { ProfileTeams } from "@/components/profile/profile-teams"
import { ProfileAchievements } from "@/components/profile/profile-achievements"
import { ProfileRegistrations } from "@/components/profile/profile-registrations"

export const dynamic = "force-dynamic"

export default async function ProfilePage() {
  // 1) Получаем сессию на сервере
  const session = await getServerSession(authOptions)
  if (!session) {
    redirect("/auth/login?callbackUrl=/profile")
  }

  const userId = session.user.id
  if (!userId) {
    redirect("/auth/login?callbackUrl=/profile")
  }

  // 2) Бежим в DB, таблица называется "User"
  const [user] = await sql<{
    id: string
    name: string
    email: string
    role: string
    region: string | null
    organization: string | null
    phone: string | null
    image: string | null
    createdAt: Date
  }[]>`
    SELECT
      "id",
      "name",
      "email",
      "role",
      "region",
      "organization",
      "phone",
      "image",
      "createdAt"
    FROM "User"
    WHERE "id" = ${userId}
  `
  if (!user) {
    redirect("/auth/login?callbackUrl=/profile")
  }

  // 3) Рендерим профиль
  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <div className="flex flex-col gap-8">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Карточка профиля */}
          <Card className="w-full md:w-1/3">
            <CardHeader className="flex flex-col items-center">
              <Avatar className="h-24 w-24">
                <AvatarImage
                  src={user.image || "/placeholder.svg"}
                  alt={user.name}
                />
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <CardTitle className="mt-4">{user.name}</CardTitle>
              <CardDescription>
                <Badge variant="outline">
                  {user.role === "ATHLETE" ? "Спортсмен" : "Организатор"}
                </Badge>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  {user.email}
                </div>
                {user.phone && (
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-2" />
                    {user.phone}
                  </div>
                )}
                {user.region && (
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2" />
                    {user.region}
                  </div>
                )}
                {user.organization && (
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    {user.organization}
                  </div>
                )}
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  Регистрация:{" "}
                  {new Date(user.createdAt).toLocaleDateString()}
                </div>
                <div className="pt-4">
                  <Button variant="outline" className="w-full">
                    Редактировать профиль
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Вкладки профиля */}
          <div className="w-full md:w-2/3">
            <Tabs defaultValue="competitions">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="competitions">Соревнования</TabsTrigger>
                <TabsTrigger value="teams">Команды</TabsTrigger>
                <TabsTrigger value="registrations">Регистрации</TabsTrigger>
                <TabsTrigger value="achievements">Достижения</TabsTrigger>
              </TabsList>
              <TabsContent value="competitions" className="mt-6">
                <ProfileCompetitions userId={user.id} userRole={user.role} />
              </TabsContent>
              <TabsContent value="teams" className="mt-6">
                <ProfileTeams userId={user.id} />
              </TabsContent>
              <TabsContent value="registrations" className="mt-6">
                <ProfileRegistrations userId={user.id} />
              </TabsContent>
              <TabsContent value="achievements" className="mt-6">
                <ProfileAchievements userId={user.id} />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
